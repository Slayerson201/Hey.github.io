<h1>Solstice</h1>
<h3>Solstic is a proxy
It is a frontend proxy that hosts ultraviolet
I am working on the backend
This is the github repo
of solstice (and ultraviolet 😭)
So ye until I finish backend the proxy looks like this
</h3>
<h2>This is the server invite to solstice so pls join</h2>
:star2: Introducing Solstice :star2:

═══════════ ︽❉︽ 𓆉 ︽❉︽ ═══════════

:sun_with_face: Welcome to Solstice! :sun_with_face:

═══════════ ︽❉︽ 𓆉 ︽❉︽ ═══════════

:star2: What We Offer :star2:
:link: Reliable Proxies to Break Through School Blocks!
:busts_in_silhouette: A Warm Community for Chatting and Bonding!
:tools: Supportive Staff Ready to Assist You!
:couple: Opportunities to Forge Lasting Friendships!
:underage: A Safe and Friendly Environment with No Inappropriate Content!

════════════ ︽❉︽ 𓆉 ︽❉︽ ════════════

:star2: Join Our Journey! :star2:
:chart_with_upwards_trend: Seeking New Members to Grow Our Community!
:shield: Looking for Dedicated and Responsible Staff!
:bulb: Welcoming Creative Minds to Spark Innovation!

════════════ ︽❉︽ 𓆉 ︽❉︽ ════════════

:star2: More About Solstice :star2:
Escape the mundane and embrace the extraordinary at Solstice! Dive into engaging conversations, forge connections with fellow members, and discover the power of proxies and game links to unlock boundless possibilities! Whether you're seeking to break free from school restrictions or simply craving a vibrant community to call home, Solstice welcomes you with open arms. Join us today and illuminate your journey with warmth and camaraderie!

═══════════ ︽❉︽ 𓆉 ︽❉︽ ═══════════

:star2: Embrace the Solstice Spirit! :star2:
:rocket: Join Now: https://discord.gg/solstice :rocket:
